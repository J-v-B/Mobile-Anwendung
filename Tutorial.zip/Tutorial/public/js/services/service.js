/*
 * Security contexts
 */
/*
 * Service settings
 */
/*
 * Services
 */
var BarcodeService = new Apperyio.BarCodeService({
    'defaultRequest': {
        "data": null
    }
});