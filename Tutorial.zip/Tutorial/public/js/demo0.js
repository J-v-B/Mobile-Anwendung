(function init() {

  // EreignisHandler auf submit-Button
  /* document.getElementById("btn01")
          .addEventListener("click", function() {
            let vorname = document.getElementById("vornameIn")
                               .value;
            let nachname = document.getElementById("nachnameIn")
                               .value;
            if(!nachname) {
              document.getElementById("f01")
                      .textContent = "kein Name!";
            } else {
              person.nachname = nachname;
              person.vorname  = vorname;

              document.getElementById("vornameOut").textContent = person.vorname;
              document.getElementById("nachnameOut").textContent = person.nachname;

              alert("Hallo " + person);

              document.getElementById("form01").submit();
            }
          });*/
  
  document.getElementById("btn02")
          .addEventListener("click", einfuegen2);
})();

function einfuegen() {
  let body = document.getElementById("tab01");

  let row   = document.createElement("tr");
  let col01 = document.createElement("td");
  let col02 = document.createElement("td");
  let col03 = document.createElement("td");

  let bild = document.createElement("img");
  bild.setAttribute("src", "gruener-Haken.png");


  col01.textContent = new Date();
  col02.textContent = "Alles gut";

  col03.appendChild(bild);

  // alternativ
  // col03.innerHTML="<span>Bild:</span><img src='grüner-Haken.png'/>";

  // row.appendChild(col01);
  // row.appendChild(col02);
  // row.appendChild(col03);
  // body.appendChild(row);

}

function einfuegen2() {
  var table = document.getElementById("tab01");
  var row = table.insertRow(-1); // Value -1 results in a new row being inserted at the last position
  var cell1 = row.insertCell(0); // Value 0 results in the new cell will be inserted at the first position. The value of -1 can also be used; which results in that the new cell will be inserted at the last position.
  var cell2 = row.insertCell(1)
  var cell3 = row.insertCell(2);
  cell1.innerHTML = new Date();
  cell2.innerHTML = "Alles gut!";
  cell3.innerHTML = "<span>Bild:</span><img src='../../public/gruener-Haken.png' width='100' />";
}