/**
 * The content will be replaced with proper javascript code during mobile application building
 */

Appery.getTargetPlatform = function() {
    return "";
}
