self.addEventListener('install', function(e) {
 e.waitUntil(
   caches.open('video-store').then(function(cache) {
     return cache.addAll([
       '.',
       'views/pages/index.ejs',
       'views/pages/main.ejs',
       'views/pages/calendar.ejs',
       'views/pages/clock.ejs',
       'views/pages/contact.ejs',
       'views/pages/counter.ejs',
       'views/pages/register.ejs',
       'views/pages/services.ejs',
       'views/pages/stamp.ejs',
       'views/partials/footer.ejs',
       'public/css/bootstrap.css',
       'public/css/font-awesome.css',
       'public/css/font-awesome.min_1.css',
       'public/css/jquery-ui.css',
       'public/css/jquery.easy-gallery.css',
       'public/css/menu_style.css',
       'public/css/simplelightbox.css',
       'public/css/startScreen.css',
       'public/css/style.css',
       'public/css/style11.css',
       'public/css/style_1.css',
       'public/css/theme/flat-ui/flat-ui.css',
       'public/css/theme/jqm/jqm.css',
       'public/fonts/fontawesome-webfont.eot',
       'public/fonts/fontawesome-webfont.svg',
       'public/fonts/fontawesome-webfont.ttf',
       'public/fonts/fontawesome-webfont.woff',
       'public/fonts/fontawesome-webfont.woff2',
       'public/fonts/FontAwesome.otf',
       'public/fonts/glyphicons-halflings-regular.woff',
       'public/fonts/glyphicons-halflings-regular.woff2',
       'public/js/services',
       'public/js/bootstrap.js',
       'public/js/cordova.js',
       'public/js/demo0.js',
       'public/js/demo1.js',
       'public/js/get_target_platform.js',
       'public/js/index.js',
       'public/js/person.js',
       'public/js/startScreen.js',
       'public/js/sw.js',
       'public/libs/apperyio',
       'public/libs/base',
       'public/libs/carousel-css-jquery-plugin',
       'public/libs/datepicker',
       'public/libs/event',
       'public/libs/exadel-carousel',
       'public/libs/jquery',
       'public/libs/jquery-ui-map',
       'public/libs/jquery-ui-youtube',
       'public/libs/jquerymobile',
       'public/libs/ms_sdk_bundle',
       'public/libs/store',
       'public/libs/underscore',
       'public/libs/vimeo',
       'public/about-left.jpg',
       'public/arrows.png',
       'public/banner4.png',
       'public/gruener-Haken.png',
       'public/iconneu.png',
       'public/tick.png',
       'public/tipp.jpg',
       
       
       
       
       'index.html',
       'index.js',
       'style.css',
       
       
       
       
       
       
       //'images/fox1.jpg',
       //'images/fox2.jpg',
       //'images/fox3.jpg',
       //'images/fox4.jpg'
     ]);
   })
 );
});

self.addEventListener('fetch', function(e) {
  console.log(e.request.url);
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});

// A simple, no-op service worker that takes immediate control.

self.addEventListener("install", function() {
  // Skip over the "waiting" lifecycle state, to ensure that our
  // new service worker is activated immediately, even if there's
  // another tab open controlled by our older service worker code.
  self.skipWaiting();
});
