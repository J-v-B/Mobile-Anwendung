// Register User
app.post('/register', function(req, res){
    var Password = req.body.Password;
    var Password2 = req.body.Password2;
    
    if (Password == Password2){
        var newUser = new User ({
            Username: req.body.Username,
            Email: reg.body.Email,
            Password: req.body.Password,
            Password2: req.body.Password2
        });
        
        User.createUser(newUser, function(err, use){
            if(err) throw err;
            res.send(user).end()
        });
    } else {
        res.status(500).send("{errors: \"Password don´t match\"}").end()
    }
});

app.listen(3000,() => console.log('App listening on port 8080!'))