var mongoose = require('mongoose');
var passportLocalMongoose = require('passport-local-mongoose');

var userDataSchema = new mongoose.Schema({
    name: String,
     passwort: String,
     Username: String,
     Email: String,
     Password: String,
     Password2: String,
     name2: String,
     termin: String,
     Name2: String,
     Email2: String,
     Betreff: String,
     Message: String
 },{collection:'userdata'});

userDataSchema.plugin(passportLocalMongoose);
module.exports=mongoose.model('User', userDataSchema);