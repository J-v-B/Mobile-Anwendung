// server.js
// load the things we need
const https = require('https');
var express = require('express');
var app = express();
var port     = process.env.PORT || 8080;
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/userdata');
var passport = require('passport');
//var User = require('./models/user');
const fs = require('fs');
var path = require('path');


app.use(bodyParser.urlencoded({extended:true}));
 var connection = mongoose.connection; 
 connection.once('open', function(){
     connection.db.collection('userdata', function(err, collection){
         collection.find({}).toArray(function(er, data){
             console.log(data);
         });
     });
 });
 
 
 var userDataSchema = new mongoose.Schema ({
     name: String,
     passwort: String,
     Username: String,
     Email: String,
     Password: String,
     Password2: String,
     name2: String,
     termin: String
 },{collection:'userdata'});
 var userData = mongoose.model('userData', userDataSchema);
 
 
app.use('/', express.static(path.join(__dirname, 'public')));



// set the view engine to ejs
app.set('view engine', 'ejs');

// use res.render to load up an ejs view file

 // index page 
app.get('/', function(req, res) {
    console.log(req.query)
   res.render('pages/index');
    
});

app.post('/', function(req, res) {
    console.log(req.query)
   res.render('pages/index');
    
});

app.get('/', function(req, res) {
    console.log(req.query)
   res.render('pages/register');
    
});

app.post('/', function(req, res) {
    console.log(req.query)
   res.render('pages/register');
    

    
});

        // Seiten//

// index page 
app.get('/index', function(req, res) {
    res.render('pages/index');
});

app.post('/insert', function(req, res){
    var variable ={
        name: req.body.name,
     passwort: req.body.passwort
    };
var data = new userData (variable);
data.save();
console.log(req.body);
res.render('pages/index.ejs');
});

// main page
app.get('/main', function(req, res) {
    res.render('pages/main');
});

// contact page 
app.get('/contact', function(req, res) {
    res.render('pages/contact');
});

// clock page 
app.get('/clock', function(req, res) {
    res.render('pages/clock');
});

// counter page 
app.get('/counter', function(req, res) {
    res.render('pages/counter');
});

// stamp page 
app.get('/stamp', function(req, res) {
    res.render('pages/stamp');
});

app.post('/insert', function(req, res){
    var variable ={
        name2: req.body.name,
        termin: req.body.termin
    };
var data = new userData (variable);
data.save();
console.log(req.body);
res.render('stamp.ejs');
});

// register page 
app.get('/register', function(req, res) {
    res.render('pages/register');
});

app.post('/insert', function(req, res){
    var variable ={
        Username: req.body.Username,
        Email: req.body.Email,
     Password: req.body.Password,
     Password2: req.body.Password2
    };
var data = new userData (variable);
data.save();
console.log(req.body);
res.render('register.ejs');
});

// calendar page 
app.get('/calendar', function(req, res) {
    res.render('pages/calendar');
});

// services page 
app.get('/services', function(req, res) {
    res.render('pages/services');
});

// Icon einbinden
app.use('/public',express.static('public'));   



            //HTTPS//

https.createServer({
    key: fs.readFileSync('server.key'),
    cert: fs.readFileSync('server.cert')},
    app).listen(4443, () => {
        console.log('Listening ...');
  })
    

//app.listen(8080);
//console.log('8080 is the magic port');





// Endpoint to login
//app.post('/login',
 // passport.authenticate('local'),
  //function(req, res) {
   // res.send(req.user);
  //}
//);

// Endpoint to get current user
//app.get('/user', function(req, res){
 // res.send(req.user);
//})


// Endpoint to logout
//app.get('/logout', function(req, res){
//  req.logout();
 // res.send(null)
//});


            //Social Media
            
//app.get('/auth/facebook',
  //passport.authenticate('facebook'));

//app.get('/auth/facebook/callback',
  //passport.authenticate('facebook', { failureRedirect: '/login' }),
  //function(req, res) {
    // Successful authentication, redirect home.
    //console.log(req.user)
    //res.redirect('/');
  //}
//);

// BodyParser Middleware
//app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({ extended: false }));
//app.use(cookieParser());

// Express Session
//app.use(session({
  //secret: 'secret',
  //saveUninitialized: true,
  //resave: true
//}));

// Passport init
//app.use(passport.initialize());
//app.use(passport.session());




//app.listen(8080, () => console.log('App listening on port 8080!'))

//var LocalStrategy = require('passport-local').Strategy;
//passport.use(new LocalStrategy(
//  function(username, password, done) {
//    User.getUserByUsername(username, function(err, user){
//      if(err) throw err;
 //     if(!user){
  //      return done(null, false, {message: 'Unknown User'});
 //     }
//      User.comparePassword(password, user.password, function(err, isMatch){
//        if(err) throw err;
//     	if(isMatch){
 //    	  return done(null, user);
 //    	} else {
  //   	  return done(null, false, {message: 'Invalid password'});
  //   	}
  //   });
 //  });
 // }
//));

//passport.serializeUser(function(user, done) {
//  done(null, user.id);
//});

//passport.deserializeUser(function(id, done) {
//  User.getUserById(id, function(err, user) {
//    done(err, user);
//  });
//});
//